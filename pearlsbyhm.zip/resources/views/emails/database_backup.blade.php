<!DOCTYPE html>
<html>
<head>
    <title>Database Backup</title>
</head>
<body>
    <p>Dear Admin,</p>
    <p>Dear Admin your website {{ site_name() }} pearlsbyhm.com has been successfully back-up Done✅</p>
    <p>Regards,<br/>{{ site_name() }}</p>
</body>
</html>
