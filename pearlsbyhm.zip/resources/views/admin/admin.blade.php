@extends('admin.layouts.app')
@section('admin_title', site_name().' | Dashboard')
@section('content2')
    <div class="container-fluid px-3">
        <h1>Welcome To Dashboard!</h1>
    </div>
@endsection
