<?php $__env->startSection('admin_title', 'Details | Order # ' . $order->tracking_id); ?>
<?php $__env->startSection('content2'); ?>
    <div class="container-fluid px-3">
        <div class="card shadow-sm bg-white rounded-0">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-6 col-sm-4">
                    <a <?php if($order->status == 'Pending'): ?> href="<?php echo e(url('admin/orders/pending')); ?>"
<?php elseif($order->status == 'In Process'): ?>
   href="<?php echo e(url('admin/orders/in-process')); ?>"
<?php elseif($order->status == 'Packed, Ready To Ship'): ?>
    href="<?php echo e(url('admin/orders/packed')); ?>"
<?php elseif($order->status == 'Sent To Parcel Delivered Company'): ?>
  href="<?php echo e(url('admin/orders/sent')); ?>"
  <?php elseif($order->status == 'Cancelled'): ?>
  href="<?php echo e(url('admin/orders/cancelled')); ?>"
<?php else: ?>
    href="<?php echo e(url('admin/orders/delivered')); ?>" <?php endif; ?>
                        class="btn btn-dark custom-back-button d-flex align-items-center justify-content-center">
                        <i class="bx bx-chevron-left me-1"></i> Back
                    </a>
                </div>
                <div class="col-lg-10 col-md-9 col-6 col-sm-8">
                    <h3 class="mt-1 d-none d-md-bloack d-lg-block" style="font-family:cursive">Details | Order #
                        <?php echo e($order->tracking_id); ?></h3>

                    <h5 class="mt-1 d-block d-md-none d-lg-none" style="font-family:cursive">Details | Order #
                        <?php echo e($order->tracking_id); ?></h5>
                </div>
            </div>
        </div>


        <style>
            .custom-back-button {
                font-size: 16px;
                height: 100%;
                width: 100%;
                border-radius: 0;
                text-decoration: none;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .custom-back-button:hover {
                background-color: #314861;
            }

            .custom-back-button i {
                font-size: 18px;
            }
        </style>

        <div class="card p-3 mt-3">
   <div class="row g-4">
                
                <div class="col-lg-6 col-md-12">
                    <h5 class="mb-3">Order Information</h5>
                    <ul class="list-group list-group-flush small">
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Order Placed:</strong>
                            <span><?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M y, h:i A')); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Tracking ID:</strong>
                            <span><?php echo e($order->tracking_id); ?></span>
                        </li>

                        <?php
                            $statusClasses = [
                                'Pending' => 'bg-danger',
                                'In Process' => 'bg-warning text-dark',
                                'Packed, Ready To Ship' => 'bg-primary',
                                'Sent To Parcel Delivered Company' => 'bg-info text-dark',
                                'default' => 'bg-success',
                            ];

                            $badgeClass = $statusClasses[$order->status] ?? $statusClasses['default'];
                        ?>

                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <strong>Status:</strong>
                            <span class="badge <?php echo e($badgeClass); ?> rounded-0 px-3 py-1">
                                <?php echo e($order->status); ?>

                            </span>
                        </li>


                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Total Products:</strong> <span><?php echo e($order->total_products); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Total Items:</strong> <span><?php echo e($order->total_items); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Full Name:</strong> <span><?php echo e($order->first_name . ' ' . $order->last_name); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Phone:</strong> <span><?php echo e($order->phone); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Address:</strong> <span><?php echo e($order->address); ?></span>
                        </li>
                        <?php if(!empty($order->landmark)): ?>
                            <li class="list-group-item px-0 d-flex justify-content-between">
                                <strong>Landmark:</strong> <span><?php echo e($order->landmark); ?></span>
                            </li>
                        <?php endif; ?>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>City:</strong> <span><?php echo e($order->city); ?></span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between">
                            <strong>Postal Code:</strong> <span><?php echo e($order->postal_code); ?></span>
                        </li>
                    </ul>
                </div>

                
                <div class="col-lg-6 col-md-12">
                    <h5 class="mb-3">Order Items</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Product</th>
                                    <th class="text-center">Qty</th>
                                    <th>Price</th>
                                    <th class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="d-flex align-items-center gap-2">
                                            <a class="nav-link" target="_Blank" href="<?php echo e(route('prduct.details', ['url' => $item->url])); ?>">
                                                <img src="<?php echo e(asset($item->product_image)); ?>" height="70" width="70"
                                                    alt="<?php echo e($item->name); ?>">
                                                <span><?php echo e($item->name ?? 'N/A'); ?></span>
                                            </a>

                                        </td>
                                        <td class="text-center"><?php echo e($item->qty); ?></td>
                                        <td>Rs. <?php echo e(number_format($item->price, 2)); ?></td>
                                        <td class="text-end">Rs. <?php echo e(number_format($item->total, 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="mt-3">
                        <ul class="list-group list-group-flush small">
                            <li class="list-group-item px-0 d-flex justify-content-between">
                                <strong>Subtotal:</strong>
                                <span>Rs. <?php echo e(number_format($order->subtotal, 2)); ?></span>
                            </li>
                            <li class="list-group-item px-0 d-flex justify-content-between">
                                <strong>Shipping:</strong>
                                <span>Rs. <?php echo e(number_format($order->shipping, 2)); ?></span>
                            </li>
                            <li class="list-group-item px-0 d-flex justify-content-between fw-bold border-top pt-2">
                                <strong>Total Bill:</strong>
                                <span>Rs. <?php echo e(number_format($order->total, 2)); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/orders/details.blade.php ENDPATH**/ ?>