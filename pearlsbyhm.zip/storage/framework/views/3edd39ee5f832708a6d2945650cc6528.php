<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to Admin Dashboard 🎉</h1>
    <p>You are logged in as Admin.</p>

    <!-- Logout Button -->
    <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" style="padding: 8px 16px; background-color: red; color: white; border: none; cursor: pointer;">
            Logout
        </button>
    </form>
</body>
</html>
<?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>