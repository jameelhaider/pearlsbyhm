<?php $__env->startSection('admin_title', site_name().' | Dashboard'); ?>
<?php $__env->startSection('content2'); ?>
    <div class="container-fluid px-3">
        <h1>Welcome To Dashboard!</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/admin.blade.php ENDPATH**/ ?>