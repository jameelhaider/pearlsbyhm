<?php $__env->startSection('title', 'Accounts - '.site_name()); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 px-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Accounts</li>
            </ol>
        </nav>

        <div class="row justify-content-center">
            <h4 class="text-center fw-bold" style="font-family: Arial, sans-serif;letter-spacing: 1px;">ACCOUNTS
            </h4>
            <h5 style="font-family: Arial, sans-serif">Hi! <?php echo e(auth()->user()->name); ?></h5>
            <div class="mt-2 d-flex">
                <a href="<?php echo e(route('address.index')); ?>" class="btn-outline-black nav-link w-50">VIEW ADDRESSES</a>
                <a href="<?php echo e(route('myorders.index')); ?>" class="btn-outline-black nav-link w-50">VIEW ORDERS</a>
            </div>
            <div class="mt-2 d-flex">
                <a href="<?php echo e(route('change.password')); ?>" class="btn-outline-black nav-link w-50">CHANGE PASSWORD</a>
                <a href="<?php echo e(route('password.request')); ?>" class="btn-outline-black nav-link w-50">RESET PASSWORD</a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/accounts/index.blade.php ENDPATH**/ ?>