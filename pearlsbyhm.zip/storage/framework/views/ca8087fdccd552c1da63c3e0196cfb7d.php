<option value="<?php echo e($category->id); ?>"
    <?php echo e(isset($selected) && $selected == $category->id ? 'selected' : ''); ?>>
    <?php echo e($prefix ?? ''); ?><?php echo e($category->name); ?>

</option>

<?php if($category->children->count()): ?>
    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.categories.partials.option', [
            'category' => $child,
            'prefix' => ($prefix ?? '') . '— ',
            'selected' => $selected ?? null
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/categories/partials/option.blade.php ENDPATH**/ ?>