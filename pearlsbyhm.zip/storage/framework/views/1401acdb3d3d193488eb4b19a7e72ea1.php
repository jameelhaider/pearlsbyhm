<?php $__env->startSection('title', 'Your Wishlist - '.site_name()); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .btn-outline-black2,
        .btn-solid-black2 {
            display: inline-block;
            font-family: 'Montserrat', Arial, sans-serif;
            letter-spacing: 2px;
            padding: 8px 0px;
            font-size: 15px;
            text-align: center;
            cursor: pointer;
            border-radius: 0;
            box-shadow: none;
            transition: all 0.4s ease;
        }

        .custom-font2 {
            font-family: Arial, sans-serif;
            letter-spacing: 1px;
            font-size: 18px;
        }

        .btn-outline-black2 {
            background-color: #fff;
            color: #000;
            border: 1px solid #000;
        }

        .btn-outline-black2:hover {
            background-color: #000;
            color: #fff;
            border-color: #000;
            opacity: 0.9;
        }

        .btn-solid-black2 {
            background-color: #000;
            color: #fff;
            border: 1px solid transparent;
            text-transform: uppercase;
        }

        .btn-solid-black2:hover {
            background-color: #fff;
            color: #000;
            border-color: #000;
            opacity: 0.9;
        }
    </style>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Your Wishlist</li>
            </ol>
        </nav>

        <h3 class="mb-4 fw-bold" style="font-family: Arial, sans-serif">Your Wishlist</h3>

        <?php if($wishlistItems->isEmpty()): ?>
            <div class="text-center my-5">
                <i style="font-size: 110px;" class="bi bi-emoji-frown"></i>
                <h2 class="text-dark fw-bold" style="font-family:Arial, sans-serif">Your WishList is empty</h2>
                <p class="text-secondary" style="font-family:Arial, sans-serif">Looks like you haven't added any items yet.
                </p>
                <a href="<?php echo e(route('products.all')); ?>" class="btn-solid-black w-75 nav-link mt-3">
                    BROWSE PRODUCTS
                </a>
            </div>
        <?php else: ?>
            <div class="container-fluid">
                <div class="row justify-content-around g-2 mt-2">
                    <?php $__currentLoopData = $wishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-12 col-md-4 col-sm-6">
                             <a href="<?php echo e(route('prduct.details', ['url' => $product->url])); ?>" class="nav-link">
                            <div class="card rounded-0 product-card">
                                <div class="image-wrapper">
                                    <img class="main-image img-fluid" src="<?php echo e(asset($product->image)); ?>"
                                        alt="<?php echo e($product->name); ?>">
                                    <img class="hover-image img-fluid" src="<?php echo e(asset($product->hover_image)); ?>"
                                        alt="<?php echo e($product->name); ?>">
                                </div>
                                <h5 class="text-center mt-2 custom-font2"><?php echo e($product->name); ?></h5>

                                <div class="d-flex justify-content-center gap-4">
                                    <h6 class="text-center mb-2 custom-font2">
                                        <del><?php echo e('Rs.' . number_format($product->actual_price, 2)); ?></del>
                                    </h6>
                                    <h6 class="text-center mb-2 custom-font2" style="color: rgb(224, 7, 7)">
                                        <?php echo e('Rs.' . number_format($product->price, 2)); ?></h6>
                                </div>

                                <div class="p-2">
                                    <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="me-1 w-100">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">
                                        <input type="hidden" name="qty" value="1">
                                        <button type="submit" class="btn-solid-black2 w-100">Move to Cart</button>
                                    </form>

                                    <form action="<?php echo e(route('wishlist.remove', $product->wishlist_id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn-outline-black2 w-100 mt-1">REMOVE FROM
                                            WISHLIST</button>
                                    </form>
                                </div>

                            </div>
                             </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <style>
                .product-card .image-wrapper {
                    position: relative;
                    overflow: hidden;
                }

                .product-card .image-wrapper img {
                    width: 100%;
                    display: block;
                    transition: opacity 0.5s ease, transform 0.6s ease;
                    transform: scale(1);
                }

                .product-card .image-wrapper .hover-image {
                    position: absolute;
                    top: 0;
                    left: 0;
                    opacity: 0;
                }

                /* Hover effect */
                .product-card:hover .image-wrapper .hover-image {
                    opacity: 1;
                    transform: scale(1.1);
                }

                .product-card:hover .image-wrapper .main-image {
                    opacity: 0;
                    transform: scale(1.1);
                }
            </style>



        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/wishlist/index.blade.php ENDPATH**/ ?>