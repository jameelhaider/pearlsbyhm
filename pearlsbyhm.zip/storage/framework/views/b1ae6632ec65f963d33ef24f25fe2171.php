<!DOCTYPE html>
<html>
<head>
    <title>Database Backup</title>
</head>
<body>
    <p>Dear Admin,</p>
    <p>Dear Admin your website <?php echo e(site_name()); ?> pearlsbyhm.com has been successfully back-up Done✅</p>
    <p>Regards,<br/><?php echo e(site_name()); ?></p>
</body>
</html>
<?php /**PATH D:\wamp64\pearlsbyhm\resources\views/emails/database_backup.blade.php ENDPATH**/ ?>