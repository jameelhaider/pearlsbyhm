<?php $__env->startSection('title', 'My Orders - '.site_name()); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 px-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
                <li class="breadcrumb-item active" aria-current="page">My Orders</li>
            </ol>
        </nav>

        <div class="row justify-content-center">
            <h4 class="text-center fw-bold" style="font-family: Arimo, sans-serif;letter-spacing: 1px;">MY ORDERS
            </h4>
              <?php if($myorders->count() > 0): ?>
            <div class="row g-2 justify-content-center">
                <?php $__currentLoopData = $myorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-10 col-lg-8">
                        <div class="card border-0 rounded-0 shadow">
                            <div class="card-body py-3 px-3">

                                
                                <div class="d-flex justify-content-between align-items-center flex-wrap mb-2">
                                    <strong style="font-family: Arial, sans-serif;">
                                        #<?php echo e($order->tracking_id); ?> |
                                        <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M y, h:i A')); ?>

                                    </strong>

                                    <?php
                                        $badgeClass = match ($order->status) {
                                            'Pending' => 'bg-danger',
                                            'In Process' => 'bg-warning text-dark',
                                            'Cancelled' => 'bg-secondary',
                                            'Packed, Ready To Ship' => 'bg-primary',
                                            'Sent To Parcel Delivered Company' => 'bg-info text-dark',
                                            default => 'bg-success',
                                        };
                                    ?>
                                    <span class="badge <?php echo e($badgeClass); ?> px-2 rounded-0 py-1"><?php echo e($order->status); ?></span>
                                </div>

                                
                                <div class="d-flex justify-content-between flex-wrap small mb-1" style="font-family: Arial, sans-serif;">
                                    <span><strong>Products:</strong> <?php echo e($order->total_products); ?></span>
                                    <span><strong>Items:</strong> <?php echo e($order->total_items); ?></span>
                                    <span><strong>Subtotal:</strong> Rs.<?php echo e(number_format($order->subtotal)); ?></span>
                                    <span><strong>Shipping:</strong> Rs.<?php echo e(number_format($order->shipping)); ?></span>
                                    <span class="fw-bold text-success"><strong>Total:</strong> Rs.<?php echo e(number_format($order->total)); ?></span>
                                </div>

                                
                                <div class="small text-muted" style="font-family: Arial, sans-serif;">
                                    <span class="d-block text-truncate" style="max-width: 100%;">
                                        <strong class="text-dark">Address:</strong>
                                        <?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?> |
                                        <?php echo e($order->phone); ?> |
                                        <?php echo e($order->city); ?>

                                        <?php if(!empty($order->postal_code)): ?>
                                            | <?php echo e($order->postal_code); ?>

                                        <?php endif; ?>
                                    </span>
                                    <span class="d-block text-truncate" style="max-width: 100%;">
                                        <?php echo e($order->address); ?>

                                        <?php if(!empty($order->landmark)): ?>
                                            | <?php echo e($order->landmark); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>

                                
                                <div class="text-end mt-2">
                                    <a href="<?php echo e(route('myorders.details',['url'=>$order->url])); ?>" class="btn-outline-black nav-link px-3 py-1 rounded-0 small">
                                        VIEW DETAILS
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            
            <div class="text-center my-5">
                <i class="bi bi-emoji-frown" style="font-size: 100px;"></i>
                <h5 class="text-dark fw-bold" style="font-family: Arial, sans-serif;">No Order Placed Yet!</h5>
                <p class="text-secondary" style="font-family: Arial, sans-serif;">Looks like you haven't placed any order yet.</p>
                <a href="<?php echo e(route('welcome')); ?>" class="btn-solid-black w-50 nav-link mt-3">
                    BROWSE PRODUCTS
                </a>
            </div>
        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/accounts/orders/myorders.blade.php ENDPATH**/ ?>