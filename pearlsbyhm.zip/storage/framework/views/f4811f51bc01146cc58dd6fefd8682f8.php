<?php $__env->startSection('title', 'FAQs - Pearls By HM'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">FAQ's</li>
            </ol>
        </nav>

        <h3 class="mb-4 fw-bold" style="font-family: Arial, sans-serif">FAQ's</h3>

        <div class="accordion" id="faqsAccordion">
            <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="accordion-item mb-3">
                    <h2 class="accordion-header" id="heading<?php echo e($faq->id); ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="false"
                            aria-controls="collapse<?php echo e($faq->id); ?>">
                            <?php echo e($faq->question); ?>

                        </button>
                    </h2>
                    <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse"
                        aria-labelledby="heading<?php echo e($faq->id); ?>" data-bs-parent="#faqsAccordion">
                        <div class="accordion-body">
                            <?php echo nl2br(e($faq->answer)); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No FAQs available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/usefulllinks/faqs.blade.php ENDPATH**/ ?>