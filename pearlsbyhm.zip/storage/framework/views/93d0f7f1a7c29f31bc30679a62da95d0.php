<?php $__env->startSection('title', 'Product | ' . $product->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-5 py-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                </li>

                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('products.all')); ?>">All Products</a>
                </li>

                <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('category.show', ['url' => $cat->url])); ?>"><?php echo e($cat->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="breadcrumb-item active" aria-current="page">
                    <?php echo e($product->name); ?>

                </li>
            </ol>
        </nav>



        <div class="row justify-content-center align-items-start">
            <div class="col-md-5 text-center mb-4 mb-md-0">

                <!-- ✅ PRODUCT IMAGE CAROUSEL -->
                <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">

                    <div class="carousel-inner">

                        <div class="carousel-item active">
                            <div class="image-zoom-container">
                                <img src="<?php echo e(asset($product->image)); ?>" class="d-block w-100 img-fluid rounded shadow-sm">
                            </div>
                        </div>

                        <?php if(!empty($product->hover_image)): ?>
                            <div class="carousel-item">
                                <div class="image-zoom-container">
                                    <img src="<?php echo e(asset($product->hover_image)); ?>"
                                        class="d-block w-100 img-fluid rounded shadow-sm">
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php $__currentLoopData = $product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <div class="image-zoom-container">
                                    <img src="<?php echo e(asset($image->image_path)); ?>"
                                        class="d-block w-100 img-fluid rounded shadow-sm">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                    <!-- ✅ Controls -->
                    <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#productCarousel"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </button>

                </div>

                <!-- ✅ Thumbnail Indicators -->
                <div class="mt-3 d-flex justify-content-center gap-2 flex-wrap">

                    <!-- Main Thumbnail -->
                    <img src="<?php echo e(asset($product->image)); ?>" data-bs-target="#productCarousel" data-bs-slide-to="0"
                        class="img-thumbnail rounded"
                        style="width: 70px; height: 70px; object-fit: cover; cursor: pointer;">

                    <?php $thumbIndex = 1; ?>

                    <!-- Hover Thumbnail -->
                    <?php if(!empty($product->hover_image)): ?>
                        <img src="<?php echo e(asset($product->hover_image)); ?>" data-bs-target="#productCarousel"
                            data-bs-slide-to="<?php echo e($thumbIndex++); ?>" class="img-thumbnail rounded"
                            style="width: 70px; height: 70px; object-fit: cover; cursor: pointer;">
                    <?php endif; ?>

                    <!-- Loop Extra Thumbnails -->
                    <?php $__currentLoopData = $product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($image->image_path)); ?>" data-bs-target="#productCarousel"
                            data-bs-slide-to="<?php echo e($thumbIndex++); ?>" class="img-thumbnail rounded"
                            style="width: 70px; height: 70px; object-fit: cover; cursor: pointer;">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>


            <div class="col-md-6">
                <h3 class="fw-bold" style="font-family: Arimo, sans-serif;"><?php echo e($product->name); ?></h3>

                <div class="my-3">
                    <span class="text-dark fs-4 fw-bold">Rs. <?php echo e(number_format($product->price)); ?></span>
                </div>

                <div class="mt-4">
                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                        <div class="input-group mb-3" style="max-width: 200px;">
                            <button type="button" class="btn btn-outline-dark rounded-0" id="decreaseQty"
                                disabled>-</button>
                            <input type="text" name="qty" id="qtyInput" class="form-control text-center"
                                value="1" readonly min="1">
                            <button type="button" class="btn btn-outline-dark rounded-0" id="increaseQty">+</button>
                        </div>

                        <button type="submit" class="btn-solid-black w-100">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </form>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const qtyInput = document.getElementById('qtyInput');
                        const decreaseBtn = document.getElementById('decreaseQty');
                        const increaseBtn = document.getElementById('increaseQty');

                        increaseBtn.addEventListener('click', function() {
                            let value = parseInt(qtyInput.value);
                            value++;
                            qtyInput.value = value;
                            if (value > 1) decreaseBtn.disabled = false;
                        });

                        decreaseBtn.addEventListener('click', function() {
                            let value = parseInt(qtyInput.value);
                            if (value > 1) {
                                value--;
                                qtyInput.value = value;
                            }
                            if (value === 1) decreaseBtn.disabled = true;
                        });
                    });
                </script>

                <!-- ✅ PRODUCT DESCRIPTION ACCORDION -->
                <div class="mt-4">
                    <div class="accordion" id="productDetailsAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingDescription">
                                <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseDescription" aria-expanded="false"
                                    aria-controls="collapseDescription">
                                    Product Description
                                </button>
                            </h2>
                            <div id="collapseDescription" class="accordion-collapse collapse"
                                aria-labelledby="headingDescription" data-bs-parent="#productDetailsAccordion">
                                <div class="accordion-body">
                                    <?php echo nl2br(e($product->description)); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ✅ END DESCRIPTION ACCORDION -->

            </div>
        </div>
    </div>


    <div class="container-fluid">
        <h3 class="text-center mt-4 fw-bold" style="font-family: Arial, sans-serif">Related Products</h3>
        <?php if($related_products->count() > 0): ?>
            <div class="row justify-content-around g-2 mt-2">
                <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-12 col-md-4 col-sm-6">
                        <a href="<?php echo e(route('prduct.details', ['url' => $product->url])); ?>" class="nav-link">
                            <div class="card rounded-0 product-card">
                                <div class="image-wrapper">
                                    <img class="main-image img-fluid" src="<?php echo e(asset($product->image)); ?>"
                                        alt="<?php echo e($product->name); ?>">
                                    <img class="hover-image img-fluid" src="<?php echo e(asset($product->hover_image)); ?>"
                                        alt="<?php echo e($product->name); ?>">
                                </div>
                                <h5 class="text-center mt-2 custom-font2"><?php echo e($product->name); ?></h5>

                                <div class="d-flex justify-content-center gap-4">
                                    <h6 class="text-center mb-2 custom-font2">
                                        <del><?php echo e('Rs.' . number_format($product->actual_price, 2)); ?></del>
                                    </h6>
                                    <h6 class="text-center mb-2 custom-font2" style="color: rgb(224, 7, 7)">
                                        <?php echo e('Rs.' . number_format($product->price, 2)); ?></h6>
                                </div>

                                <div class="p-2">
                                    <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="me-1 w-100">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="qty" value="1">
                                        <button type="submit" class="btn-solid-black2 w-100">Add to Cart</button>
                                    </form>

                                    <form action="<?php echo e(route('wishlist.add')); ?>" method="POST" class="w-100 mt-1">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                        <button type="submit" class="btn-outline-black2 w-100">ADD TO WISHLIST</button>
                                    </form>
                                </div>

                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
                <div class="text-center my-5">
                <i style="font-size: 110px;" class="bi bi-emoji-frown"></i>
                <h2 class="text-dark fw-bold" style="font-family:Arial, sans-serif">No Related Products Found...</h2>
                <p class="text-secondary" style="font-family:Arial, sans-serif">Looks like no products there.
                </p>
                <a href="<?php echo e(route('products.all')); ?>" class="btn-solid-black w-75 nav-link mt-3">
                    BROWSE OTHERS
                </a>
            </div>

        <?php endif; ?>

    </div>



    <style>
        .btn-outline-black2,
        .btn-solid-black2 {
            display: inline-block;
            font-family: 'Montserrat', Arial, sans-serif;
            letter-spacing: 2px;
            padding: 8px 0px;
            font-size: 15px;
            text-align: center;
            cursor: pointer;
            border-radius: 0;
            box-shadow: none;
            transition: all 0.4s ease;
        }

        .custom-font2 {
            font-family: Arial, sans-serif;
            letter-spacing: 1px;
            font-size: 18px;
        }

        .btn-outline-black2 {
            background-color: #fff;
            color: #000;
            border: 1px solid #000;
        }

        .btn-outline-black2:hover {
            background-color: #000;
            color: #fff;
            border-color: #000;
            opacity: 0.9;
        }

        .btn-solid-black2 {
            background-color: #000;
            color: #fff;
            border: 1px solid transparent;
            text-transform: uppercase;
        }

        .btn-solid-black2:hover {
            background-color: #fff;
            color: #000;
            border-color: #000;
            opacity: 0.9;
        }
    </style>
    <style>
        .product-card .image-wrapper {
            position: relative;
            overflow: hidden;
        }

        .product-card .image-wrapper img {
            width: 100%;
            display: block;
            transition: opacity 0.5s ease, transform 0.6s ease;
            transform: scale(1);
        }

        .product-card .image-wrapper .hover-image {
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
        }

        /* Hover effect */
        .product-card:hover .image-wrapper .hover-image {
            opacity: 1;
            transform: scale(1.1);
        }

        .product-card:hover .image-wrapper .main-image {
            opacity: 0;
            transform: scale(1.1);
        }
    </style>

    <style>
        .image-zoom-container {
            position: relative;
            overflow: hidden;
        }

        .image-zoom-container img {
            width: 100%;
            transition: transform 0.1s ease-in-out;
        }

        .image-zoom-container.zoom-active img {
            transform: scale(2);
            /* Zoom Level — increase if needed */
            cursor: crosshair;
        }
    </style>


    <script>
        document.querySelectorAll('.image-zoom-container').forEach(container => {
            const img = container.querySelector('img');

            container.addEventListener('mousemove', function(e) {
                const rect = container.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width * 100;
                const y = (e.clientY - rect.top) / rect.height * 100;

                container.classList.add('zoom-active');
                img.style.transformOrigin = `${x}% ${y}%`;
            });

            container.addEventListener('mouseleave', function() {
                container.classList.remove('zoom-active');
                img.style.transformOrigin = 'center';
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/products/details.blade.php ENDPATH**/ ?>