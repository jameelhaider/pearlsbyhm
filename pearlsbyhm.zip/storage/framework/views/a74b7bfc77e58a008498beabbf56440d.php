<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset(site_logo())); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>

<style>
    * {
        font-family: 'Arimo', sans-serif !important;
    }

    .custom-font {
        font-family: Arial, sans-serif;
        letter-spacing: 1px;
        font-size: 13px;
    }

    .form-control {
        height: 50px;
        border-radius: 0;
        box-shadow: none;
        font-size: 13px;
        padding: 16px;
    }

    .form-control:focus {
        border-color: #000;
        box-shadow: none;
    }
</style>

<style>
    .breadcrumb {
        background: transparent;
        margin-bottom: 1rem;
        font-size: 15px;
    }

    .breadcrumb-item+.breadcrumb-item::before {
        content: "›";
        color: #6c757d;
    }
</style>

<body>


    <style>
        .loader-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.8);
            /* Semi-transparent white background */
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* Ensure it appears above other elements */
        }

        .loader {
            width: 50px;
            aspect-ratio: 1;
            display: grid;
            border-radius: 50%;
            background: linear-gradient(0deg, rgb(0 0 0/50%) 30%, #0000 0 70%, rgb(0 0 0/100%) 0) 50%/8% 100%,
                linear-gradient(90deg, rgb(0 0 0/25%) 30%, #0000 0 70%, rgb(0 0 0/75%) 0) 50%/100% 8%;
            background-repeat: no-repeat;
            animation: l23 1s infinite steps(12);
        }

        .loader::before,
        .loader::after {
            content: "";
            grid-area: 1/1;
            border-radius: 50%;
            background: inherit;
            opacity: 0.915;
            transform: rotate(30deg);
        }

        .loader::after {
            opacity: 0.83;
            transform: rotate(60deg);
        }

        @keyframes l23 {
            100% {
                transform: rotate(1turn);
            }
        }
    </style>
    
    <div class="loader-wrapper">
        <div class="loader"></div>
    </div>
    <script>
        function hideLoader() {
            document.querySelector('.loader-wrapper').style.display = 'none';
        }
        setTimeout(function() {
            if (document.readyState === 'complete') {
                hideLoader();
            } else {
                document.onreadystatechange = function() {
                    if (document.readyState === 'complete') {
                        hideLoader();
                    }
                };
            }
        }, 700);
    </script>
    











    <!-- ================= Floating Action Buttons ================= -->

    <!-- WhatsApp Button (Bottom Left) -->
    <a href="https://wa.me/923158425273" target="_blank"
        class="btn btn-success shadow-lg d-flex align-items-center justify-content-center rounded-0 floating-btn whatsapp-btn">
        <i class="bi bi-whatsapp fs-3"></i>
    </a>

    <!-- Cart Button (Bottom Right) -->
    <?php if(!request()->routeIs('cart.index')): ?>
        <a href="<?php echo e(route('cart.index')); ?>"
            class="btn btn-dark shadow-lg d-flex align-items-center justify-content-center rounded-0 floating-btn cart-btn position-fixed">
            <i class="bi bi-cart fs-4"></i>

            <?php $cartCount = getCartItemCount(); ?>
            <?php if($cartCount > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo e($cartCount); ?>

                </span>
            <?php endif; ?>
        </a>
    <?php endif; ?>


    <!-- ================= Styles ================= -->
    <style>
        /* Common Floating Button Style */
        .floating-btn {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            z-index: 1055;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .floating-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
        }

        /* WhatsApp Button (Bottom Left) */
        .whatsapp-btn {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background-color: #25D366;
            border: none;
        }

        /* Cart Button (Bottom Right) */
        .cart-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #000;
            border: none;
        }

        /* Badge Styling */
        .cart-btn .badge {
            font-size: 0.7rem;
            padding: 0.3em 0.5em;
        }
    </style>








    <div id="app">
        <div class="py-1" style="background-color: #000;color:white">
            <h5 class="text-center mt-1" style="font-family: Arial, sans-serif">Free delivery on order above <?php echo e('Rs.'. number_format(shipping_free_on())); ?></h5>
        </div>
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset(site_logo())); ?>"
                        height="60px" width="70px" alt=""> <span style="font-size: 20px"
                        class="fw-bold"><?php echo e(site_name()); ?></span></a>

                

                <!-- Offcanvas Toggler Button -->
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>







                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto"></ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link mt-2 <?php echo e(Route::is('welcome') ? 'active text-dark' : ''); ?>"
                                style="font-size: 1.2rem;" href="<?php echo e(route('welcome')); ?>">
                                <?php echo e(__('Home')); ?>

                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link mt-2 <?php echo e(Route::is('track.order') ? 'active text-dark' : ''); ?>"
                                style="font-size: 1.2rem;" href="<?php echo e(route('track.order')); ?>">
                                <?php echo e(__('Track My Order')); ?>

                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link mt-2 <?php echo e(Route::is('wishlist.index') ? 'active text-dark' : ''); ?>"
                                style="font-size: 1.2rem;" href="<?php echo e(route('wishlist.index')); ?>">
                                <?php echo e(__('Wish List')); ?>

                            </a>
                        </li>


                        <li class="nav-item">
                            <a class="nav-link" href="#" data-bs-toggle="offcanvas"
                                data-bs-target="#offcanvasLogin" aria-controls="offcanvasLogin">
                                <i class="bi bi-person" style="font-size: 1.7rem;"></i>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('cart.index') ? 'active text-dark' : ''); ?>"
                                href="<?php echo e(route('cart.index')); ?>">
                                <i class="bi bi-cart" style="font-size: 1.7rem;"></i>
                                <span class="badge bg-dark rounded-0"><?php echo e(getCartItemCount()); ?></span>
                            </a>
                        </li>


                    </ul>
                </div>
            </div>
        </nav>



        
        <div class="d-none d-lg-block d-xl-block d-md-block">
            <div class="p-2 bg-light d-flex justify-content-center gap-5 position-relative">
                <div>
                    <a href="<?php echo e(route('products.all')); ?>" class="category-link">
                        All Products
                    </a>
                </div>
                <?php $__currentLoopData = getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="dropdown">
                        <a href="<?php echo e(url('category/' . $category->url)); ?>" class="category-link">
                            <?php echo e($category->name); ?>

                        </a>
                        <?php if($category->children->count() > 0): ?>
                            <ul class="dropdown-menu p-2">
                                <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown-submenu position-relative">
                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                            href="<?php echo e(url('category/' . $subcategory->url)); ?>">
                                            <span><?php echo e($subcategory->name); ?></span>
                                            <?php if($subcategory->children->count() > 0): ?>
                                                <span class="submenu-arrow">›</span>
                                            <?php endif; ?>
                                        </a>
                                        <?php if($subcategory->children->count() > 0): ?>
                                            <ul class="dropdown-menu p-2 sub-submenu">
                                                <?php $__currentLoopData = $subcategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(url('category/' . $subsubcategory->url)); ?>">
                                                            <?php echo e($subsubcategory->name); ?>

                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>



        <style>
            /* ===== GENERAL STYLING ===== */
            .category-link {
                text-decoration: none;
                color: #000;
                font-weight: 600;
                cursor: pointer;
                padding: 8px 12px;
                display: inline-block;
                transition: color 0.2s ease;
            }

            .category-link:hover {
                color: #007bff;
            }

            /* ===== DROPDOWN CORE BEHAVIOR ===== */
            .dropdown:hover>.dropdown-menu {
                display: block;
            }

            .dropdown-submenu:hover>.dropdown-menu {
                display: flex;
            }

            .dropdown-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                min-width: 220px;
                background: #fff;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
                border-radius: 6px;
                z-index: 1000;
                padding: 8px 0;
                flex-direction: column;
                flex-wrap: wrap;
                /* makes long lists wrap instead of overflow */
                white-space: normal !important;
            }

            .dropdown-item {
                cursor: pointer;
                padding: 6px 12px;
                white-space: normal;
                word-break: break-word;
                transition: background-color 0.2s;
            }

            .dropdown-item:hover {
                background-color: #f8f9fa;
            }

            /* ===== REMOVE DEFAULT BOOTSTRAP TOGGLE ARROW ===== */
            .dropdown-toggle::after {
                display: none !important;
            }

            /* ===== SUB-SUBMENU OPENING TO RIGHT ===== */
            .dropdown-submenu>.dropdown-menu {
                top: 0;
                left: 100%;
                margin-left: 2px;
                min-width: 220px;
            }

            /* ===== ARROW FOR SUBCATEGORIES WITH CHILDREN ===== */
            .submenu-arrow {
                font-size: 14px;
                color: #888;
                transition: transform 0.2s ease, color 0.2s ease;
            }

            .dropdown-submenu:hover>a>.submenu-arrow {
                transform: translateX(2px);
                color: #007bff;
            }

            /* ===== OPTIONAL STYLING FOR RESPONSIVE WRAP ===== */
            @media (max-width: 768px) {

                .dropdown-menu,
                .sub-submenu {
                    position: static;
                    box-shadow: none;
                    flex-wrap: wrap;
                }
            }
        </style>



        <main>
            <?php if(session('success')): ?>
                <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger text-center"><?php echo e(session('error')); ?></div>
            <?php endif; ?>







            <?php if(Request::is('/') && getslides()->count() > 0): ?>
                <div class="carousel slide mt-1" id="slider" data-bs-ride="carousel">
                    <ul class="carousel-indicators">
                        <?php $__currentLoopData = getslides(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php if($loop->first): ?> active <?php endif; ?>"
                                data-bs-slide-to="<?php echo e($key); ?>" data-bs-target="#slider"></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="carousel-inner carousel-fade">
                        <?php $__currentLoopData = getslides(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
                                <?php if($slide->link): ?>
                                    <a href="<?php echo e($slide->link); ?>" class="nav-link">
                                        <img class="d-block w-100 img-fluid" src="<?php echo e($slide->image); ?>"
                                            alt="Slide Image">
                                    </a>
                                <?php else: ?>
                                    <img class="d-block w-100 img-fluid" src="<?php echo e($slide->image); ?>"
                                        alt="Slide Image">
                                <?php endif; ?>




                                <?php if($slide->text || $slide->link): ?>
                                    <div class="carousel-caption">
                                        <?php if($slide->text): ?>
                                            <h5 class="text-white mb-2"><?php echo e($slide->text); ?></h5>
                                        <?php endif; ?>


                                    </div>
                                <?php endif; ?>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button class="carousel-control-next" data-bs-slide="next" data-bs-target="#slider">
                        <span class="carousel-control-next-icon"></span>
                    </button>
                    <button class="carousel-control-prev" data-bs-slide="prev" data-bs-target="#slider">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                </div>
            <?php endif; ?>

            <style>
                .carousel-item img {
                    pointer-events: none;
                    user-drag: none;
                    -webkit-user-drag: none;
                }
            </style>

            <script>
                document.addEventListener('contextmenu', function(e) {
                    if (e.target.tagName === 'IMG' && e.target.closest('.carousel-item')) {
                        e.preventDefault();
                    }
                });
            </script>



            <?php echo $__env->yieldContent('content'); ?>








        </main>
    </div>






    <style>
        .btn-outline-black,
        .btn-solid-black {
            display: inline-block;
            font-family: 'Montserrat', Arial, sans-serif;
            letter-spacing: 2px;
            padding: 12px 45px;
            font-size: 15px;
            text-align: center;
            cursor: pointer;
            border-radius: 0;
            box-shadow: none;
            transition: all 0.4s ease;
        }

        .btn-outline-black {
            background-color: #fff;
            color: #000;
            border: 1px solid #000;
        }

        .btn-outline-black:hover {
            background-color: #000;
            color: #fff;
            border-color: #000;
            opacity: 0.9;
        }

        .btn-solid-black {
            background-color: #000;
            color: #fff;
            border: 1px solid transparent;
            text-transform: uppercase;
        }

        .btn-solid-black:hover {
            background-color: #fff;
            color: #000;
            border-color: #000;
            opacity: 0.9;
        }
    </style>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasLogin" aria-labelledby="offcanvasLoginLabel">
        <div class="offcanvas-header">
            <?php if(auth()->guard()->guest()): ?>
                <h5 class="offcanvas-title custom-font" id="offcanvasLoginLabel">Login</h5>
            <?php else: ?>
                <h5 class="offcanvas-title fw-bold" style="font-family:Arial, sans-serif" id="offcanvasLoginLabel">
                    Hi, <?php echo e(Auth::user()->name); ?>

                </h5>
            <?php endif; ?>



            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                aria-label="Close"></button>
        </div>

        <div class="offcanvas-body p-0">

            <?php if(auth()->guard()->guest()): ?>
                <div class="p-3">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="email" class="custom-font my-2">Your Email Address <span
                                    class="text-danger">*</span></label>
                            <input id="email" type="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="custom-font my-2">Password <span
                                    class="text-danger">*</span></label>
                            <input id="password" type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                autocomplete="current-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember2"
                                <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label custom-font" for="remember2"><?php echo e(__('Remember Me')); ?></label>
                        </div>
                        <button type="submit" class="w-100 btn-solid-black">Log In</button>
                        <?php if(Route::has('password.request')): ?>
                            <div class="mt-3 text-center">
                                <a class="small text-dark custom-font" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                    </form>
                    <a class="btn-outline-black btn mt-3 w-100" href="<?php echo e(route('register')); ?>">
                        CREATE ACCOUNT
                    </a>
                </div>
            <?php else: ?>
                <ul class="list-group list-group-flush">

                    <li class="list-group-item <?php echo e(request()->routeIs('accounts.index') ? 'active' : ''); ?>"
                        style="font-family: Arial, sans-serif;">
                        <a href="<?php echo e(route('accounts.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('accounts.index') ? 'text-white' : 'text-dark'); ?>">
                            Account Details
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('address.index') ? 'active' : ''); ?>"
                        style="font-family: Arial, sans-serif;">
                        <a href="<?php echo e(route('address.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('address.index') ? 'text-white' : 'text-dark'); ?>">
                            My Addresses
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('myorders.index') ? 'active' : ''); ?>"
                        style="font-family: Arial, sans-serif;">
                        <a href="<?php echo e(route('myorders.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('myorders.index') ? 'text-white' : 'text-dark'); ?>">
                            My Orders
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('password.request') ? 'active' : ''); ?>"
                        style="font-family: Arial, sans-serif;">
                        <a href="<?php echo e(route('password.request')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('password.request') ? 'text-white' : 'text-dark'); ?>">
                            Reset Your Password
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('change.password') ? 'active' : ''); ?>"
                        style="font-family: Arial, sans-serif;">
                        <a href="<?php echo e(route('change.password')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('change.password') ? 'text-white' : 'text-dark'); ?>">
                            Change Your Password
                        </a>
                    </li>

                    <li class="list-group-item" style="font-family: Arial, sans-serif;">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="btn btn-link text-decoration-none text-dark p-0 m-0 d-block text-start">
                                Log Out
                            </button>
                        </form>
                    </li>

                </ul>


            <?php endif; ?>



        </div>
    </div>














    <!-- ================= Offcanvas Sidebar ================= -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar"
        aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body p-0">

            <!-- ===== Public Links ===== -->
            <ul class="list-group list-group-flush">

                <li class="list-group-item <?php echo e(request()->routeIs('welcome') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('welcome')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('welcome') ? 'text-white' : 'text-dark'); ?>">
                        Home
                    </a>
                </li>
                <li class="list-group-item <?php echo e(request()->routeIs('cart.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('cart.index')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('cart.index') ? 'text-white' : 'text-dark'); ?>">
                        My Cart
                        <span
                            class="badge float-end rounded-0 <?php echo e(request()->routeIs('cart.index') ? 'bg-white text-dark' : 'bg-dark text-white'); ?>">
                            <?php echo e(getCartItemCount()); ?>

                        </span>
                    </a>
                </li>

                <li class="list-group-item <?php echo e(request()->routeIs('products.all') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('products.all')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('products.all') ? 'text-white' : 'text-dark'); ?>">
                        All Products
                    </a>
                </li>

                <li class="list-group-item <?php echo e(request()->routeIs('shop.category') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('shop.category')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('shop.category') ? 'text-white' : 'text-dark'); ?>">
                        Shop By Category
                    </a>
                </li>

                <li class="list-group-item <?php echo e(request()->routeIs('track.order') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('track.order')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('track.order') ? 'text-white' : 'text-dark'); ?>">
                        Track My Order
                    </a>
                </li>

                <li class="list-group-item <?php echo e(request()->routeIs('wishlist.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('wishlist.index')); ?>"
                        class="text-decoration-none d-block <?php echo e(request()->routeIs('wishlist.index') ? 'text-white' : 'text-dark'); ?>">
                        My Wishlist
                    </a>
                </li>



                <?php if(auth()->guard()->guest()): ?>
                    <li class="list-group-item <?php echo e(request()->routeIs('login') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('login')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('login') ? 'text-white' : 'text-dark'); ?>">
                            Login
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('register') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('register')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('register') ? 'text-white' : 'text-dark'); ?>">
                            Register
                        </a>
                    </li>
                <?php else: ?>
                    <li class="list-group-item <?php echo e(request()->routeIs('accounts.index') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('accounts.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('accounts.index') ? 'text-white' : 'text-dark'); ?>">
                            Account Details
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('address.index') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('address.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('address.index') ? 'text-white' : 'text-dark'); ?>">
                            My Addresses
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('myorders.index') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('myorders.index')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('myorders.index') ? 'text-white' : 'text-dark'); ?>">
                            My Orders
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('password.request') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('password.request')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('password.request') ? 'text-white' : 'text-dark'); ?>">
                            Reset Your Password
                        </a>
                    </li>

                    <li class="list-group-item <?php echo e(request()->routeIs('change.password') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('change.password')); ?>"
                            class="text-decoration-none d-block <?php echo e(request()->routeIs('change.password') ? 'text-white' : 'text-dark'); ?>">
                            Change Your Password
                        </a>
                    </li>

                    <li class="list-group-item">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="btn btn-link text-decoration-none text-dark p-0 m-0 d-block text-start">
                                Log Out
                            </button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>


        </div>
    </div>

    <!-- ================= Styles ================= -->
    <style>
        .list-group-item {
            font-family: Arial, sans-serif;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .list-group-item:hover {
            background-color: #f8f9fa;
        }

        .list-group-item.active {
            background-color: #000 !important;
            color: #fff !important;
            border-color: #000 !important;
        }

        .list-group-item.active a {
            color: #fff !important;
        }

        .offcanvas {
            width: 280px;
        }
    </style>












    <!-- Footer -->
    <footer class="bg-dark text-light pt-5 pb-4">
        <div class="container text-center text-md-start">
            <div class="row">

                <!-- Brand / About -->
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold text-uppercase mb-3"><?php echo e(site_name()); ?></h5>
                    <p class="small text-light">
                      <?php echo e(site_description()); ?>

                    </p>
                    <div>
                        <a href="#" class="text-light me-3 fs-5"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="text-light me-3 fs-5"><i class="bi bi-instagram"></i></a>
                        <a href="https://wa.me/923158425273" target="_BLANK" class="text-light fs-5"><i
                                class="bi bi-whatsapp"></i></a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-md-3 mb-4">
                    <h6 class="fw-bold text-uppercase mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo e(route('welcome')); ?>" class="footer-link">Home</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('cart.index')); ?>" class="footer-link">My Cart</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('wishlist.index')); ?>" class="footer-link">My
                                Wishlist</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('track.order')); ?>" class="footer-link">Track My
                                Order</a></li>
                                <?php $__currentLoopData = getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <li class="mb-2"><a href="<?php echo e(route('category.show',['url'=>$category->url])); ?>" class="footer-link"><?php echo e('Shop For '. $category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Customer Support -->
                <div class="col-md-3 mb-4">
                    <h6 class="fw-bold text-uppercase mb-3">Customer Support</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo e(route('privacy')); ?>" class="footer-link">Privacy Policy</a>
                        </li>

                        <li class="mb-2"><a href="<?php echo e(route('return')); ?>" class="footer-link">Exchange &
                                Return</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('shipping')); ?>" class="footer-link">Shipping
                                Policy</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('terms')); ?>" class="footer-link">Terms &
                                Conditions</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('cancel')); ?>" class="footer-link">Order Cancel
                                Policy</a></li>
                        <li class="mb-2"><a href="<?php echo e(route('faqs')); ?>" class="footer-link">FAQs</a></li>

                    </ul>
                </div>

                <!-- Contact -->
                <div class="col-md-2 mb-4">
                    <h6 class="fw-bold text-uppercase mb-3">Contact</h6>
                    <p class="small mb-1"><i class="bi bi-geo-alt-fill me-2"></i>Gujranwala, Pakistan</p>
                    <a href="https://wa.me/923158425273" target="_BLANK" class="nav-link">
                        <p class="small mb-1"><i class="bi bi-telephone-fill me-2"></i>+92 315 8425273</p>
                    </a>
                    <a href="mailto:pearlsbyhm@gmail.com" target="_blank" class="nav-link d-block">
                        <p class="small mb-1"><i class="bi bi-envelope-fill me-2"></i>pearlsbyhm@gmail.com</p>
                    </a>


                </div>

            </div>
        </div>

        <hr class="border-light opacity-25">

        <!-- Bottom -->
        <div class="text-center small text-light">
            © <span id="year"></span> <?php echo e(site_name()); ?>. All Rights Reserved. <br>
            Developed by
            <a href="https://wa.me/923366886889" target="_blank"
                class="text-success text-decoration-none fw-semibold">
                JH Developers
            </a>
        </div>
    </footer>


    <style>
        .footer-link {
            color: #bbb;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-link:hover {
            color: #fff;
            text-decoration: underline;
        }

        footer .bi {
            transition: color 0.3s ease, transform 0.3s ease;
        }

        footer .bi:hover {
            color: #0d6efd;
            transform: translateY(-3px);
        }

        footer hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
        }
    </style>

    <script>
        // Auto-update copyright year
        document.getElementById("year").textContent = new Date().getFullYear();
    </script>

</body>

</html>
<?php /**PATH D:\wamp64\pearlsbyhm\resources\views/layouts/app.blade.php ENDPATH**/ ?>