<?php $__env->startSection('title', 'My Addresses - Pearls By HM'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 px-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Addresses</li>
            </ol>
        </nav>

        <div class="row justify-content-center">
            <h4 class="text-center fw-bold" style="font-family: Arimo, sans-serif;letter-spacing: 1px;">MY ADDRESSES
            </h4>
            <a href="" class="btn-solid-black nav-link">ADD NEW ADDRESS</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>NAME</th>
                        <th>PHONE</th>
                        <th>ADDRESS</th>
                        <th class="text-center">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $myaddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th class="text-center" style="font-family: Arial, sans-serif"><?php echo e(++$key); ?></th>
                            <td style="font-family: Arial, sans-serif">
                                <?php echo e($address->first_name . ' ' . $address->last_name); ?></td>
                            <td style="font-family: Arial, sans-serif"><?php echo e($address->phone); ?></td>
                            <td style="font-family: Arial, sans-serif">
                                <?php echo e($address->address); ?>

                                <?php if(!empty($address->landmark)): ?>
                                    | <?php echo e($address->landmark); ?>

                                <?php endif; ?>
                                <?php if(!empty($address->postal_code)): ?>
                                    | <?php echo e($address->postal_code); ?>

                                <?php endif; ?>
                            </td>


                            <td class="text-center"><a href="" class="btn-outline-black nav-link">EDIT ADDRESS</a>
                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/accounts/myaddresses.blade.php ENDPATH**/ ?>