<?php echo e($slot); ?>

<?php /**PATH D:\wamp64\pearlsbyhm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>