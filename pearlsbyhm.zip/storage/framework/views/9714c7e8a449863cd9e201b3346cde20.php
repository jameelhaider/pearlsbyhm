<?php $__env->startSection('title', 'Forgot Password - '.site_name()); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <?php if(Auth::check()): ?>
  <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page">Forgot Password</li>
            </ol>
        </nav>

        <div class="row justify-content-center">
            <h4 class="text-center fw-bold" style="font-family: Arimo, sans-serif;letter-spacing: 1px;">RESET YOUR PASSWORD
            </h4>
            <p class="text-center mt-4" style="font-family: Arimo, sans-serif">We will send you an email to reset your
                password enter email to get your account back</p>

            <div class="col-md-8 col-lg-5 mt-2 col-12 col-sm-11 col-xl-5">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <label for="" class="custom-font my-2">Your Email Address <span
                                    class="text-danger">*</span></label>
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mb-0">
                        <div class="col-lg-12">

                            <style>
                                .btn-create-account {
                                    display: inline-block;
                                    background-color: #fff;
                                    color: #000;
                                    font-family: 'Montserrat', Arial, sans-serif;
                                    letter-spacing: 2px;
                                    padding: 12px 45px;
                                    border: 1px solid #000;
                                    border-radius: 0;
                                    font-size: 15px;
                                    box-shadow: none;
                                    text-align: center;
                                    cursor: pointer;
                                    transition:
                                        background-color 0.4s ease,
                                        color 0.4s ease,
                                        border-color 0.4s ease,
                                        opacity 0.4s ease;
                                }

                                .btn-create-account:hover {
                                    background-color: #000;
                                    color: #fff;
                                    border-color: #000;
                                    opacity: 0.9;
                                }
                            </style>


                            <button type="submit" class="btn-create-account mt-2">
                                Send Password Reset Link
                            </button>
                            <?php if(Auth::check()): ?>
<a class="text-dark ms-3 custom-font" href="<?php echo e(route('accounts.index')); ?>">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                            <?php else: ?>
                            <a class="text-dark ms-3 custom-font" href="<?php echo e(route('login')); ?>">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                            <?php endif; ?>

                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>