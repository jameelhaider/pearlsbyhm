<?php if($address->id): ?>
    <?php $__env->startSection('title', 'Edit Address - Pearls By HM'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Add Address - Pearls By HM'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 px-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                  <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('address.index')); ?>">Addresses</a></li>
                <li class="breadcrumb-item active" aria-current="page">
                    <?php if($address->id): ?>
                        Edit Address
                    <?php else: ?>
                        Add Address
                    <?php endif; ?>
                </li>
            </ol>
        </nav>

        <div class="row justify-content-center">
            <h4 class="text-center fw-bold" style="font-family: Arimo, sans-serif;letter-spacing: 1px;">
                <?php if($address->id): ?>
                    EDIT ADDRESS
                <?php else: ?>
                    ADD ADDRESS
                <?php endif; ?>
            </h4>
            <a href="<?php echo e(route('address.index')); ?>" class="btn-solid-black nav-link">BACK TO ADDRESSES</a>
            <div class="card p-3 rounded-0 mt-2">
                <form
                    action="<?php echo e($address->id != null ? route('address.update', ['id' => $address->id]) : route('address.save')); ?>"
                    method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" value="<?php echo e(old('first_name', $address->first_name)); ?>"
                                class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="First Name">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">Last Name <span class="text-danger">*</span></label>
                            <input type="text" name="last_name" value="<?php echo e(old('last_name', $address->last_name)); ?>"
                                class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Last Name">
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-4 col-md-12 col-12 col-sm-12">
                            <label class="custom-font my-2">Phone <span class="text-danger">*</span></label>
                            <input type="text" name="phone" value="<?php echo e(old('phone', $address->phone)); ?>"
                                placeholder="0300-0000000" maxlength="12"
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <script>
                            document.addEventListener("DOMContentLoaded", function() {
                                const phoneInput = document.getElementById('phone');
                                if (!phoneInput.value) {
                                    phoneInput.value = '03';
                                }
                                phoneInput.addEventListener('focus', function() {
                                    if (phoneInput.value === '') {
                                        phoneInput.value = '03';
                                    }
                                });
                                phoneInput.addEventListener('input', function(e) {
                                    let value = e.target.value.replace(/\D/g, '');
                                    if (!value.startsWith('03')) {
                                        value = '03' + value.replace(/^0+/, '');
                                    }
                                    value = value.slice(0, 11);
                                    let formatted = value;
                                    if (value.length > 4) {
                                        formatted = value.slice(0, 4) + '-' + value.slice(4);
                                    }
                                    e.target.value = formatted;
                                });
                                phoneInput.addEventListener('keydown', function(e) {
                                    if ((phoneInput.selectionStart <= 2 && (e.key === 'Backspace' || e.key === 'Delete'))) {
                                        e.preventDefault();
                                    }
                                });
                            });
                        </script>


                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-8 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">Address <span class="text-danger">*</span></label>
                            <input type="text" name="address" value="<?php echo e(old('address', $address->address)); ?>"
                                class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Address">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">City <span class="text-danger">*</span></label>
                            <input type="text" name="city" value="<?php echo e(old('city', $address->city)); ?>"
                                class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="City Name">
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-6 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">Landmark (optional)</label>
                            <input type="text" name="landmark" value="<?php echo e(old('landmark', $address->landmark)); ?>"
                                class="form-control <?php $__errorArgs = ['landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Apartment, suite, etc. (optional)">
                            <?php $__errorArgs = ['landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-6 col-md-6 col-12 col-sm-12">
                            <label class="custom-font my-2">Postal Code (optional)</label>
                            <input type="text" name="postal_code"
                                value="<?php echo e(old('postal_code', $address->postal_code)); ?>"
                                class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Postal Code (optional)">
                            <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>



                    <button type="submit" class="btn-outline-black mt-3 w-100">
                        <?php if($address->id): ?>
                            UPDATE ADDRESS
                        <?php else: ?>
                            SAVE ADDRESS
                        <?php endif; ?>
                    </button>



                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/accounts/address/create.blade.php ENDPATH**/ ?>