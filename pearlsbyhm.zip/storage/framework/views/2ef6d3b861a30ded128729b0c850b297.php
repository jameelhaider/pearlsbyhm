<li class="tree-item">
    <div class="tree-row">
        <span class="tree-name"><?php echo e($category->name); ?></span>

        <div>
            <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <a href="<?php echo e(route('admin.category.delete', $category->id)); ?>" class="btn btn-sm btn-outline-danger"
               onclick="return confirm('Delete this category?')">
               Delete
            </a>
        </div>
    </div>

    <?php if($category->children->count()): ?>
        <ul class="tree-list">
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.categories.partials.category-item', ['category' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/categories/partials/category-item.blade.php ENDPATH**/ ?>