<?php $__env->startSection('admin_title', 'Admin | Categories'); ?>

<?php $__env->startSection('content2'); ?>
<style>
    .tree-list {
        list-style: none;
        padding-left: 25px;
        position: relative;
    }

    .tree-item {
        position: relative;
        padding: 6px 0;
        margin-left: 15px;
    }

    .tree-item::before {
        content: "";
        position: absolute;
        top: -10px;
        left: -15px;
        border-left: 1px solid #999;
        height: calc(100% + 20px);
    }

    .tree-item::after {
        content: "";
        position: absolute;
        top: 12px;
        left: -15px;
        width: 15px;
        border-top: 1px solid #999;
    }

    .tree-item:last-child::before {
        height: 12px;
    }

    .tree-row {
        display: flex;
        justify-content: space-between;
        width: 100%;
        border-bottom: 1px dashed #ccc;
        padding-bottom: 4px;
    }

    .tree-name {
        font-weight: 500;
        white-space: nowrap;
    }
</style>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>All Categories</h3>
        <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Add Category
        </a>
    </div>

    <?php if($categories->count()): ?>
        <ul class="tree-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.categories.partials.category-item', ['category' => $category], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <div class="alert alert-info">No categories found.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>