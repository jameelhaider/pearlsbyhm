<?php $__env->startSection('title', 'Track My Order - '.site_name()); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Track My Order</li>
            </ol>
        </nav>

        <div class="row justify-content-center mb-4">
            <div class="col-lg-8 text-center">
                <h4 class="fw-bold" style="font-family: Arimo, sans-serif; letter-spacing: 1px;">
                    Track My Order
                </h4>
                <p class="text-muted">Enter your tracking ID below to check your order status.</p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6">
                <form action="<?php echo e(route('track.order')); ?>" method="GET" class="card rounded-0 p-4">
                    <div class="mb-3">
                        <label for="tracking_id" class="form-label fw-bold">Tracking ID</label>
                        <input type="text" name="tracking_id" id="tracking_id" value="<?php echo e(request('tracking_id')); ?>"
                            class="form-control" placeholder="Enter your tracking ID (e.g. TRK-A9X3LZ)" required>
                    </div>

                    <button type="submit" class="btn-solid-black w-100">
                        <i class="bi bi-search me-1"></i> Track Order
                    </button>

                    <a href="<?php echo e(route('track.order')); ?>" class="btn-outline-black nav-link w-100 mt-2">CLEAR | TRACK NEW</a>

                </form>


            </div>
        </div>

        
        <?php if($order): ?>
            <div class="row justify-content-center mt-5">
                <div class="col-lg-8">
                    <div class="card rounded-0">
                        <div class="card-header rounded-0 bg-dark text-white fw-bold">
                            Order Details
                        </div>
                        <div class="card-body">
                            <p><strong>Tracking ID:</strong> <?php echo e($order->tracking_id); ?></p>
                            <p><strong>Status:</strong>
                                <span
                                    class="badge
                                <?php if($order->status === 'Pending'): ?> bg-danger
                                <?php elseif($order->status === 'In Process'): ?> bg-warning text-dark
                                <?php elseif($order->status === 'Packed, Ready To Ship'): ?> bg-primary
                                <?php elseif($order->status === 'Cancelled'): ?> bg-secondary
                                <?php elseif($order->status === 'Sent To Parcel Delivered Company'): ?> bg-info text-dark
                                <?php else: ?> bg-success <?php endif; ?>">
                                    <?php echo e($order->status); ?>

                                </span>
                            </p>
                            <?php
                                $maskedPhone = $order->phone
                                    ? substr($order->phone, 0, 2) . '**-*****' . substr($order->phone, -2)
                                    : 'N/A';
                            ?>

                            <p><strong>Phone:</strong> <?php echo e($maskedPhone); ?></p>

                            <p><strong>Placed On:</strong>
                                <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M Y, h:i A')); ?></p>
                            <p><strong>Total Amount:</strong> Rs. <?php echo e(number_format($order->total, 2)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif(request('tracking_id')): ?>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-6 text-center">
                    <div class="alert alert-danger rounded-0">
                        No order found for the tracking ID: <strong><?php echo e(request('tracking_id')); ?></strong>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\pearlsbyhm\resources\views/orders/trackmyorder.blade.php ENDPATH**/ ?>